The GWTNote sample is a bit buggy, so it was removed from the distribution,
but the source code remains in place for reference or future updates.

Jul 30 2008

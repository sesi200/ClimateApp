document.write("Offline!");
